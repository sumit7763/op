#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
using namespace std;

int main(){
    int f1, f2;
    char copy;
    f1= open("abc.txt",O_RDONLY);
    if(f1==-1){
        cout<<"File does not exist";
        close(f1);
        return 0;
    }
    f2= open("xyz.txt",O_WRONLY|O_CREAT, S_IRUSR|S_IWUSR);

    while(read(f1,&copy,1)){
        write(f2,& copy,1);
    }
    cout<<"Copied Successfully"<<endl;
    close(f1);
    close(f2);
    return 0;
}