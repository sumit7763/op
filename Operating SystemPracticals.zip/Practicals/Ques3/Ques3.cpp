#include<iostream>
#include<stdlib.h>
using namespace std;

int main(){
    cout<<"Amount of Free Space: "<<endl;
    system("cat /proc/meminfo |awk 'NR==2 {print$2}'");
    
    cout<<"Amount of Used Memory: "<<endl;
    system("cat /proc/meminfo |awk '{if(NR==1) a=$2; if(NR==2) b=$2 END {print a-b}'");
    return 0;
}