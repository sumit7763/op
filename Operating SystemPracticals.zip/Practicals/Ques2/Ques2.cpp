#include<iostream>
#include<stdlib.h>
using namespace std;

int main(){
    cout<<"Kernel Version"<<endl;
    system("cat /proc/sys/kernel/osrelease");
    cout<<endl<<endl<<endl;

    cout<<"CPU Info "<<endl;
    system("cat /proc/cpuinfo");
    cout<<endl<<endl<<endl;

    cout<<"Memory Info"<<endl;
    system("cat /proc/meminfo");
    return 0;
}